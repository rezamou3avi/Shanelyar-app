
import 'package:flutter/material.dart';

void main() => runApp(ShanlyarApp());

class ShanlyarApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'شانل‌یار',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('شانل‌یار')),
      body: Center(child: Text('خوش آمدید به شانل‌یار!')),
    );
  }
}
